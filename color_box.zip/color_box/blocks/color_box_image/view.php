<?
defined('C5_EXECUTE') or die(_("Access Denied."));
echo($controller->getContentAndGenerate());
?>